package com.veeva.vault.vapil.api.model.response;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.veeva.vault.vapil.api.model.VaultModel;

public class HelloWorldResponse extends VaultResponse {
    @JsonProperty("data")
    public HellowWorldData getData() {
        return (HellowWorldData)this.get("data");
    }

    @JsonProperty("data")
    public void setData(HellowWorldData data) {
        this.set("data", data);
    }

    public static class HellowWorldData extends VaultModel {
        @JsonProperty("hello")
        public String getHello() {
            return this.getString("hello");
        }

        public void setHello(String hello) {
            this.set("hello", hello);
        }
    }
}
