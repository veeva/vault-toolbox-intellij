/*---------------------------------------------------------------------
 *	Copyright (c) 2021 Veeva Systems Inc.  All Rights Reserved.
 *	This code is based on pre-existing content developed and
 *	owned by Veeva Systems Inc. and may only be used in connection
 *	with the deliverable with which it was provided to Customer.
 *---------------------------------------------------------------------
 */
package com.veeva.vault.vapil.api.request;

import com.veeva.vault.vapil.api.model.response.HelloWorldResponse;
import com.veeva.vault.vapil.api.model.response.VaultResponse;
import com.veeva.vault.vapil.connector.HttpRequestConnector;
import com.veeva.vault.vapil.connector.HttpRequestConnector.HttpMethod;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class HelloWorldRequest extends VaultRequest<HelloWorldRequest> {
	private static Logger log = LoggerFactory.getLogger(HelloWorldRequest.class);

	// API Endpoints
	private static final String URL_TEST = "v26.1/custom/hello_world";

	private HelloWorldRequest() {
	}

	/**
	 * <b>Test - Custom WebAPI</b>
	 * <p>
	 * Execute Test API
	 *
	 * @return HelloWorldResponse
	 * @vapil.api <pre>
	 * POST /api/{version}/custom/test</pre>
	 * @vapil.request <pre>
	 * HelloWorldResponse response = vaultClient.newRequest(HelloWorldRequest.class).helloWorld();
	 * </pre>
	 */
	public HelloWorldResponse helloWorld() {
		String url = vaultClient.getAPIEndpoint(URL_TEST, false);

		HttpRequestConnector request = new HttpRequestConnector(url);
		return send(HttpMethod.POST, request, HelloWorldResponse.class);
	}
}
