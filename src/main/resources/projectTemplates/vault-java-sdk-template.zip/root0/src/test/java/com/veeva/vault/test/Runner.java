package com.veeva.vault.test;

import com.veeva.vault.vapil.api.client.VaultClient;
import com.veeva.vault.vapil.api.model.response.HelloWorldResponse;
import com.veeva.vault.vapil.api.model.response.ObjectRecordBulkResponse;
import com.veeva.vault.vapil.api.model.response.ObjectRecordResponse;
import com.veeva.vault.vapil.api.model.response.VaultResponse;
import com.veeva.vault.vapil.api.request.HelloWorldRequest;
import com.veeva.vault.vapil.api.request.ObjectRecordRequest;

import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Objects;

public class Runner {
    public static void main(String[] args) {
        //Create client from a settings file (resources/vault.json)
        VaultClient vaultClient = getVaultClientFromSettings();

        HelloWorldResponse response = vaultClient.newRequest(HelloWorldRequest.class).helloWorld();
        if (response != null && response.isSuccessful()) {
            System.out.println("Hello " + response.getData().getHello());
        }

        String now = ZonedDateTime.now().format(DateTimeFormatter.ISO_INSTANT);
        String helloJson = "[{\"name__v\":\"" + now + "\"}]";
        ObjectRecordBulkResponse objectRecordBulkResponse = vaultClient.newRequest(ObjectRecordRequest.class)
                .setRequestString(helloJson)
                .setContentTypeJson()
                .createAndUpsertObjectRecords("hello_world__c");
        if (objectRecordBulkResponse != null) {

            displayErrorsAndWarnings(objectRecordBulkResponse);

            if (!objectRecordBulkResponse.isFailure()) {
                for (int i = 0; i < objectRecordBulkResponse.getData().size(); i++) {
                    ObjectRecordResponse objectRecordResponse = objectRecordBulkResponse.getData().get(i);
                    System.out.println("row " + i + " : " + objectRecordResponse.getResponseStatus() + " : " + objectRecordResponse.getData().getId());
                    displayErrorsAndWarnings(objectRecordResponse);
                }
            }
        }
    }

    static void displayErrorsAndWarnings(VaultResponse vaultResponse) {
        if (vaultResponse != null) {
            if (vaultResponse.isFailure()) {
                for (int i = 0; i < vaultResponse.getErrors().size(); i++) {
                    VaultResponse.APIResponseError error = vaultResponse.getErrors().get(i);
                    System.out.println(i + ": " + error.getMessage());
                }
            }
            else if (vaultResponse.isWarning()) {
                for (int i = 0; i < vaultResponse.getWarnings().size(); i++) {
                    VaultResponse.APIResponseWarning warning = vaultResponse.getWarnings().get(i);
                    System.out.println(i + ": " + warning.getMessage());
                }
            }
        }
    }

    static VaultClient getVaultClientFromSettings() {
        try {
            String vapilSettings = new String(Objects.requireNonNull(ClassLoader.getSystemResourceAsStream("vault.json")).readAllBytes());
            return VaultClient
                    .newClientBuilderFromSettings(vapilSettings)
                    .withVaultClientId("vault-java-sdk-hello-world")
                    .build();
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
}