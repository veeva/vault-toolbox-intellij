package com.veeva.vault.custom.webapi;

import com.veeva.vault.sdk.api.core.ServiceLocator;
import com.veeva.vault.sdk.api.executeas.ExecuteAs;
import com.veeva.vault.sdk.api.executeas.ExecuteAsUser;
import com.veeva.vault.sdk.api.json.JsonObject;
import com.veeva.vault.sdk.api.json.JsonService;
import com.veeva.vault.sdk.api.webapi.*;

@ExecuteAs(ExecuteAsUser.REQUEST_OWNER)
@WebApiInfo(endpointName = "hello_world", minimumVersion = "v25.3", apiGroup = "hello_world__c")
public class HelloWorldApi implements WebApi {
	@Override
	public WebApiResponse execute(WebApiContext webApiContext) {

		JsonService jsonService = ServiceLocator.locate(JsonService.class);
		JsonObject jsonObject = jsonService.newJsonObjectBuilder()
				.setValue("hello", "world").build();

		return webApiContext.newWebApiResponseBuilder()
				.withResponseStatus(WebApiResponseStatus.SUCCESS)
				.withData(jsonObject)
				.build();
	}
}
