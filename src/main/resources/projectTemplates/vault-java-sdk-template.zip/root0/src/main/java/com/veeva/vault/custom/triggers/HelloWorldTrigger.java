package com.veeva.vault.custom.triggers;
/*
 * --------------------------------------------------------------------
 * RecordTrigger:			ExampleTrigger
 * Object:					hello_world__c
 * Author:					AuthorName
 * Date:					YYYY-MM-DD
 *---------------------------------------------------------------------
 * Description: Example SDK Record Trigger
 *---------------------------------------------------------------------
 */

import com.veeva.vault.sdk.api.data.RecordChange;
import com.veeva.vault.sdk.api.data.RecordEvent;
import com.veeva.vault.sdk.api.data.RecordTrigger;
import com.veeva.vault.sdk.api.data.RecordTriggerContext;
import com.veeva.vault.sdk.api.data.RecordTriggerInfo;

@RecordTriggerInfo(object = "hello_world__c" ,
        events = {RecordEvent.BEFORE_INSERT})
public class HelloWorldTrigger implements RecordTrigger {

    public void execute(RecordTriggerContext context) {
        //best practice: only execute if not in migration mode
        if (!context.isMigrationModeEnabled()) {

            //loop through all record
            for (RecordChange recordChange : context.getRecordChanges()) {
                //String id = recordChange.getNew().getValue("id", ValueType.STRING);
                //recordChange.setError("CUSTOM_SDK", "This failed!");
                recordChange.getNew().setValue("comment__c", "Hello World");
            }
        }
    }
}