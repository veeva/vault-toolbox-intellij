/*---------------------------------------------------------------------
 *	Copyright (c) 2021 Veeva Systems Inc.  All Rights Reserved.
 *	This code is based on pre-existing content developed and
 *	owned by Veeva Systems Inc. and may only be used in connection
 *	with the deliverable with which it was provided to Customer.
 *---------------------------------------------------------------------
 */
package com.veeva.vault.vapil.api.request;

import com.veeva.vault.vapil.api.model.response.VaultInformationResponse;
import com.veeva.vault.vapil.connector.HttpRequestConnector;
import com.veeva.vault.vapil.connector.HttpRequestConnector.HttpMethod;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class VaultInformationRequest extends VaultRequest<VaultInformationRequest> {
	private static Logger log = LoggerFactory.getLogger(VaultInformationRequest.class);

	// API Endpoints
	private static final String URL_GET_VAULT_INFORMATION = "/custom/get_vault_information";

	private VaultInformationRequest() {
	}

	/**
	 * <b>Vault Information - Custom WebAPI</b>
	 * <p>
	 * Retrieve Vault Information including id, dns, name,
	 *
	 * @return VaultInformationResponse
	 * @vapil.api <pre>
	 * POST /api/{version}/custom/get_vault_information</pre>
	 * @vapil.request <pre>
	 * VaultInformationResponse response = vaultClient.newRequest(VaultInformationRequest.class)
	 * 				.getVaultInformation();</pre>
	 * @vapil.response <pre>
	 * if (response != null && response.isSuccessful()) {
	 * 		VaultInformationResponse.VaultInformation vaultInformation = response.getData();
	 *
	 * 		System.out.println("id = " + vaultInformation.getId());
	 *		System.out.println("dns = " + vaultInformation.getDns());
	 *		System.out.println("domain = " + vaultInformation.getDomain());
	 *		System.out.println("language = " + vaultInformation.getLanguage());
	 *		System.out.println("name = " + vaultInformation.getName());
	 *		System.out.println("local = " + vaultInformation.getLocal());
	 *		System.out.println("timezone = " + vaultInformation.getTimezone());
	 *
	 *	}
	 * }</pre>
	 */
	public VaultInformationResponse getVaultInformation() {
		String url = vaultClient.getAPIEndpoint(URL_GET_VAULT_INFORMATION);

		HttpRequestConnector request = new HttpRequestConnector(url);
		return send(HttpMethod.POST, request, VaultInformationResponse.class);
	}
}
