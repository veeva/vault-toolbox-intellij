package com.helloworld;

import com.veeva.vault.vapil.api.client.VaultClient;
import com.veeva.vault.vapil.api.model.response.QueryResponse;
import com.veeva.vault.vapil.api.model.response.VaultInformationResponse;
import com.veeva.vault.vapil.api.request.QueryRequest;
import com.veeva.vault.vapil.api.request.VaultInformationRequest;

public class Main {
    public static void main(String[] args) {
        //Create client from a settings file (resources/vault.json)
        VaultClient vaultClient = getVaultClientFromSettings();

        //alternative: create client from username/password
        // VaultClient vaultClient = getVaultClientFromBasic();

        queryDemo(vaultClient);

        //this method requires configuring custom webapi
        //customWebApiDemo(vaultClient);
    }

    static VaultClient getVaultClientFromBasic() {
        return VaultClient
                .newClientBuilder(VaultClient.AuthenticationType.BASIC)
                .withVaultDNS("verteobiotech.veevavault.com")
                .withVaultUsername("username@verteobiotech.com")
                .withVaultPassword("Password")
                .withVaultClientId("vapil-demo")
                .build();
    }

    static VaultClient getVaultClientFromSettings() {
        try {
            String vapilSettings = new String(ClassLoader.getSystemResourceAsStream("vault.json").readAllBytes());
            return VaultClient
                    .newClientBuilderFromSettings(vapilSettings)
                    .withVaultClientId("vapil-demo")
                    .build();
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    static void queryDemo(VaultClient vaultClient) {
        // Perform a VQL query and display the results
        QueryResponse resp = vaultClient.newRequest(QueryRequest.class)
                .query("SELECT name__v, email__sys FROM user__sys MAXROWS 3");
        if (resp != null) {
            System.out.println("-----------------------------------------");
            System.out.println("Response Status = " + resp.getResponseStatus());
            System.out.println("Total Records = " + resp.getData().size());
            for (QueryResponse.QueryResult row : resp.getData())
                System.out.println("Name = " + row.get("name__v") + ", Email = " + row.get("email__sys"));
        }
    }

    static void customWebApiDemo(VaultClient vaultClient) {
        VaultInformationResponse response = vaultClient.newRequest(VaultInformationRequest.class).getVaultInformation();
        if (response != null && response.isSuccessful()) {
            VaultInformationResponse.VaultInformation vaultInformation = response.getData();

            System.out.println("id = " + vaultInformation.getId());
            System.out.println("dns = " + vaultInformation.getDns());
            System.out.println("domain = " + vaultInformation.getDomain());
            System.out.println("language = " + vaultInformation.getLanguage());
            System.out.println("name = " + vaultInformation.getName());
            System.out.println("local = " + vaultInformation.getLocal());
            System.out.println("timezone = " + vaultInformation.getTimezone());

        }
    }
}