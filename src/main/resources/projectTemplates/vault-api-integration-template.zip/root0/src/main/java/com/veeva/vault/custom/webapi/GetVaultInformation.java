package com.veeva.vault.custom.webapi;

import com.veeva.vault.sdk.api.core.ServiceLocator;
import com.veeva.vault.sdk.api.core.VaultInformation;
import com.veeva.vault.sdk.api.core.VaultInformationService;
import com.veeva.vault.sdk.api.data.Record;
import com.veeva.vault.sdk.api.executeas.ExecuteAs;
import com.veeva.vault.sdk.api.executeas.ExecuteAsUser;
import com.veeva.vault.sdk.api.json.JsonObjectBuilder;
import com.veeva.vault.sdk.api.json.JsonService;
import com.veeva.vault.sdk.api.webapi.*;



@ExecuteAs(ExecuteAsUser.REQUEST_OWNER)
@WebApiInfo(endpointName = "get_vault_information", minimumVersion = "v24.3", apiGroup = "general__c")
public class GetVaultInformation implements WebApi {
	@Override
	public WebApiResponse execute(WebApiContext webApiContext) {

		VaultInformationService vaultInformationService = ServiceLocator.locate(VaultInformationService.class);
		VaultInformation vaultInformation = vaultInformationService.getLocalVaultInformation();
		JsonService jsonService = ServiceLocator.locate(JsonService.class);
		JsonObjectBuilder responseDataBuilder = jsonService.newJsonObjectBuilder()
				.setValue("id", vaultInformation.getId())
				.setValue("dns", vaultInformation.getDns())
				.setValue("domain", vaultInformation.getDomain())
				.setValue("name", vaultInformation.getName())
				.setValue("language", vaultInformation.getLanguageCode())
				.setValue("local", vaultInformation.getLocaleCode())
				.setValue("timezone", vaultInformation.getTimeZoneName());

		return webApiContext.newWebApiResponseBuilder()
				.withResponseStatus(WebApiResponseStatus.SUCCESS)
				.withData(responseDataBuilder.build())
				.build();
	}
}






