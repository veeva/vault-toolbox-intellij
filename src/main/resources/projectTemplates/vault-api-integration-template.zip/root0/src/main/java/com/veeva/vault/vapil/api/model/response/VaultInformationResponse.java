//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package com.veeva.vault.vapil.api.model.response;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.veeva.vault.vapil.api.model.VaultModel;

public class VaultInformationResponse extends VaultResponse {
    @JsonProperty("data")
    public VaultInformation getData() {
        return (VaultInformation)this.get("data");
    }

    @JsonProperty("data")
    public void setData(VaultInformation data) {
        this.set("data", data);
    }

    public static class VaultInformation extends VaultModel {
        @JsonProperty("id")
        public String getId() {
            return this.getString("id");
        }

        public void setId(String id) {
            this.set("id", id);
        }

        @JsonProperty("dns")
        public String getDns() {
            return this.getString("dns");
        }

        public void setDns(String dns) {
            this.set("dns", dns);
        }

        @JsonProperty("domain")
        public String getDomain() {
            return this.getString("domain");
        }

        public void setDomain(String domain) {
            this.set("domain", domain);
        }

        @JsonProperty("name")
        public String getName() {
            return this.getString("name");
        }

        public void setName(String name) {
            this.set("name", name);
        }

        @JsonProperty("language")
        public String getLanguage() {
            return this.getString("language");
        }

        public void setLanguage(String language) {
            this.set("language", language);
        }

        @JsonProperty("local")
        public String getLocal() {
            return this.getString("local");
        }

        public void setLocal(String local) {
            this.set("local", local);
        }

        @JsonProperty("timezone")
        public String getTimezone() {
            return this.getString("timezone");
        }

        public void setTimezone(String timezone) {
            this.set("timezone", timezone);
        }
    }
}
